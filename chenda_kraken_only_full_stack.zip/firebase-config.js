// firebase-config.js
// No Firebase initialization on this page; stub avoids 404 and keeps future option open.
window.FIREBASE_ENABLED = false;